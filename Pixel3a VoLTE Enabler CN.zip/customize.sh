#!/sbin/sh

SKIPUNZIP=1

ui_print "********************************"
ui_print "   Pixel 3a VoLTE Fix Module    "
ui_print "   Powered by Xiaomi 8 SE MBN   "
ui_print "********************************"

ui_print "- 正在解压文件..."
unzip -o "$ZIPFILE" -d "$MODPATH" >&2

# 定义路径变量
MBN_DIR="$MODPATH/system/vendor/rfs/msm/mpss/readonly/vendor/mbn/mcfg_sw"
TXT_FILE="$MBN_DIR/mbn_sw.txt"

ui_print "- 生成精确的 MBN 索引列表..."
# 确保目录存在
mkdir -p "$MBN_DIR"

# 写入索引文件。这里使用的是相对路径，告诉基带去 mbns/xiaomi/ 下找文件
# 这行命令会覆盖旧的索引，防止系统去扫描其他数千个文件
echo "mbns/xiaomi/cmcc.mbn" > "$TXT_FILE"
echo "mbns/xiaomi/ct.mbn" >> "$TXT_FILE"
echo "mbns/xiaomi/cu.mbn" >> "$TXT_FILE"
echo "mbns/xiaomi/cmhk.mbn" >> "$TXT_FILE"

ui_print "- 设置文件权限..."
set_perm_recursive "$MODPATH" 0 0 0755 0644

ui_print "- 清除基带缓存 (强制重读配置)..."
# 这是最关键的一步，删除缓存文件让基带重启后读取新的 mbn_sw.txt
rm -f /data/vendor/modem_fdr/fdr_check
rm -f /data/vendor/radio/modem_config
rm -f /data/vendor/radio/power_config

ui_print "********************************"
ui_print "  安装完成！请重启手机。       "
ui_print "  重启后需等待约 1-2 分钟生效   "
ui_print "********************************"